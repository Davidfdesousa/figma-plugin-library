# Post Mortem — Ícones publicados que precisaram ser ocultados sem remoção da CDN

## 1. Identificação

- **ID:** PM-2026-002
- **Data do ocorrido:** [DD/MM/YYYY]
- **Data do registro:** 14/08/2026
- **Autor:** David Ferreira
- **Área afetada:** icons
- **Severidade:** S3 — inconsistência entre fontes, sem quebra de consumo
- **Status:** Em correção

## 2. Resumo

Foram publicados 4 ícones em um mesmo ciclo. Após a publicação, identificamos que 2 deles não deveriam estar disponíveis para consumo. Como os arquivos já estavam na CDN, remover não era uma opção viável sem gerar breaking change, então a correção foi ocultá-los no Figma e no catálogo, mantendo os assets servidos.

## 3. Impacto

- **Quem foi afetado:** designers (visibilidade indevida no Figma) e times consumidores (ícones visíveis no catálogo como se fossem oficiais)
- **O que ficou incorreto:** 2 ícones expostos como disponíveis sem terem passado por validação final
- **Houve breaking change?** Não. A decisão de ocultar em vez de remover existiu justamente para evitar isso.
- **Como foi detectado:** revisão interna após a publicação

## 4. Linha do tempo

- **[DD/MM HH:MM]** — Publicação do lote com 4 ícones (Figma, CDN e catálogo)
- **[DD/MM HH:MM]** — Identificado que 2 dos ícones não deveriam estar disponíveis
- **[DD/MM HH:MM]** — Avaliada a remoção da CDN e descartada por risco de breaking change
- **[DD/MM HH:MM]** — Definida a estratégia de ocultação em Figma e catálogo
- **[DD/MM HH:MM]** — Ajuste aplicado

## 5. Causa raiz

**3 porquês:**

1. Por que ícones indevidos ficaram públicos? → Porque foram publicados no mesmo lote de ícones válidos.
2. Por que foram publicados junto? → Porque a validação de "este ícone está pronto para consumo" acontece depois da publicação, não antes.
3. Por que a validação acontece depois? → Porque o pipeline não tem um estado intermediário entre "existe no repositório" e "está disponível para consumo". Publicar e disponibilizar são a mesma ação hoje.

**Causa raiz em uma frase:** o pipeline de ícones não separa publicação de disponibilização, então todo ícone que entra no lote vira automaticamente ícone oficial.

## 6. Restrições que guiaram a decisão

- Nenhum asset é removido da CDN após publicado. URLs são contrato com os times consumidores.
- Ocultar é reversível. Apagar não é.
- Figma e catálogo são superfícies de descoberta. CDN é superfície de consumo. Elas podem divergir de forma controlada.

## 7. Correção aplicada

- Ícones ocultados na biblioteca do Figma
- Ícones ocultados no catálogo de ícones
- Assets mantidos na CDN, acessíveis por URL direta

## 8. Prevenção

Proposta para validação do time:

- **Ação:** introduzir um campo de visibilidade no metadata do ícone (ex.: `visibility: "public" | "hidden"` ou `status: "stable" | "hidden" | "deprecated"`), tornando a ocultação um estado versionado e não uma ação manual em duas ferramentas separadas
- **Ação complementar:** teste unitário que garante que ícone marcado como `hidden` continua presente na saída da CDN e ausente do catálogo, protegendo a regra de não remoção
- **Tipo:** Automatizada
- **Dono:** [nome]
- **Prazo:** [DD/MM/YYYY]
- **Status:** Pendente

## 9. Aprendizado

- Publicar e disponibilizar precisam ser etapas distintas. Sem esse estado intermediário, qualquer erro de lote vira erro público.
- A regra de nunca remover da CDN funcionou bem como restrição, mas só existia na cabeça do time. Restrição não documentada é restrição que alguém vai quebrar.
- Ocultação em duas ferramentas manualmente é frágil. Enquanto a visibilidade não for metadata, ela vai divergir.

# Post Mortem — [Título curto do que aconteceu]

> Documento sem culpados. O objetivo é entender o sistema que permitiu o erro, não quem cometeu.
> Meta de preenchimento: 15 minutos. Se passar disso, está detalhado demais.

## 1. Identificação

- **ID:** PM-[YYYY]-[NNN]
- **Data do ocorrido:** [DD/MM/YYYY]
- **Data do registro:** [DD/MM/YYYY]
- **Autor:** [nome]
- **Área afetada:** [tokens | icons | illustrations | plugins | pipeline | docs]
- **Severidade:** [S1 | S2 | S3 | S4]
- **Status:** [Aberto | Em correção | Resolvido | Monitorando]

### Escala de severidade

- **S1** — Breaking change publicado. Consumidores quebrados em produção.
- **S2** — Ativo incorreto publicado e exposto, sem quebra de consumo.
- **S3** — Inconsistência interna entre fontes (Figma, catálogo, CDN, docs).
- **S4** — Processo ou cosmético. Sem impacto em consumidor.

## 2. Resumo

[Máximo 3 linhas, linguagem simples. Alguém de fora do time precisa entender lendo só isso.]

## 3. Impacto

- **Quem foi afetado:** [times, marcas, plataformas]
- **O que ficou incorreto:** [ativo, versão, comportamento]
- **Houve breaking change?** [Sim / Não — e por quê]
- **Como foi detectado:** [report de time consumidor | revisão interna | teste | pipeline]

## 4. Linha do tempo

- **[DD/MM HH:MM]** — [evento]
- **[DD/MM HH:MM]** — [evento]
- **[DD/MM HH:MM]** — [detecção]
- **[DD/MM HH:MM]** — [correção aplicada]

## 5. Causa raiz

**3 porquês:**

1. Por que [sintoma]? → Porque [causa imediata].
2. Por que [causa imediata]? → Porque [causa do processo].
3. Por que [causa do processo]? → Porque [causa estrutural — é aqui que a ação preventiva nasce].

**Causa raiz em uma frase:** [frase única e objetiva]

## 6. Restrições que guiaram a decisão

[Regras não negociáveis que limitaram as opções de correção. Ex.: nada é removido da CDN, versionamento semântico, contratos com times consumidores.]

## 7. Correção aplicada

- [O que foi feito para resolver o caso concreto]
- [Versão publicada / PR / commit]

## 8. Prevenção

- **Ação:** [o que impede que aconteça de novo]
- **Tipo:** [Automatizada (teste, lint, CI) | Manual (checklist, review) | Documental]
- **Dono:** [nome]
- **Prazo:** [DD/MM/YYYY]
- **Status:** [Pendente | Em andamento | Concluída]

> Regra do time: toda ação preventiva deve tender à automação. Checklist manual é solução temporária, não final.

## 9. Aprendizado

- [1 a 3 bullets. O que o time leva desse caso para os próximos.]

# Post Mortems — Ícones

Registro de incidentes da fundação do Design System relacionados ao pipeline de ícones.

## Como usar

1. Copie `postmortem-template.md` e renomeie para `pm-[ano]-[numero]-[slug-curto].md`
2. Preencha em até 15 minutos, no mesmo dia da correção
3. Abra PR junto com o commit da correção, quando possível
4. Adicione o caso na lista abaixo

Post mortem aqui é blameless. O documento existe para corrigir o sistema, não para registrar responsáveis.

## Casos registrados

- **PM-2026-001** — Ícone substituído por colisão de nome entre variantes — S1 — Resolvido
- **PM-2026-002** — Ícones publicados que precisaram ser ocultados sem remoção da CDN — S3 — Em correção

## Padrões identificados

Os dois primeiros casos apontam para a mesma origem estrutural: o metadata do ícone não carrega informação suficiente sobre sua identidade e seu estado.

- **PM-2026-001** — a variante não é um campo, é convenção dentro do nome
- **PM-2026-002** — a visibilidade não é um campo, é ação manual em duas ferramentas

Ambos se resolvem com a mesma refatoração: metadata explícito de ícone com `name`, `variant` e `visibility` como campos versionados.

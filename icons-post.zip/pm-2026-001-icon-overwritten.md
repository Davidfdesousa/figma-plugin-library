# Post Mortem — Ícone substituído por colisão de nome entre variantes

## 1. Identificação

- **ID:** PM-2026-001
- **Data do ocorrido:** [DD/MM/YYYY]
- **Data do registro:** 14/08/2026
- **Autor:** David Ferreira
- **Área afetada:** icons
- **Severidade:** S1 — conteúdo do asset alterado silenciosamente na mesma URL
- **Status:** Resolvido

> Nota sobre a severidade: não houve quebra de build, mas consumidores que já usavam a variante preenchida passaram a receber a variante não preenchida sem nenhum aviso. Breaking change silencioso é pior que erro ruidoso, porque ninguém é alertado. Se o ícone ainda não tinha consumo em produção, rebaixar para S2.

## 2. Resumo

Um ícone que possui as variantes preenchida e não preenchida teve a versão não preenchida publicada com o mesmo nome da já existente. Em vez de somar como nova variante, a publicação substituiu o asset anterior. A variante preenchida deixou de existir e a mesma URL passou a servir um desenho diferente.

## 3. Impacto

- **Quem foi afetado:** times consumidores que utilizavam a variante preenchida do ícone
- **O que ficou incorreto:** a URL da variante preenchida passou a servir a variante não preenchida
- **Houve breaking change?** Sim. O contrato da URL foi mantido, mas o conteúdo entregue mudou.
- **Como foi detectado:** [report de time consumidor | revisão interna — completar]

## 4. Linha do tempo

- **[DD/MM HH:MM]** — Publicação da variante não preenchida usando o mesmo nome da variante existente
- **[DD/MM HH:MM]** — Variante preenchida sobrescrita no pipeline e na CDN
- **[DD/MM HH:MM]** — Identificada a substituição
- **[DD/MM HH:MM]** — Republicação da variante preenchida com o nome correto
- **[DD/MM HH:MM]** — Teste unitário de nomes duplicados implementado

## 5. Causa raiz

**3 porquês:**

1. Por que a variante preenchida desapareceu? → Porque a não preenchida foi publicada com nome idêntico e sobrescreveu o arquivo.
2. Por que a sobrescrita aconteceu sem aviso? → Porque o pipeline trata o nome como chave e grava por substituição, sem detectar colisão antes de publicar.
3. Por que duas variantes diferentes podem ter o mesmo nome? → Porque a variante não é um campo próprio na identidade do ícone. Ela só existe por convenção dentro da string do nome, então o pipeline não tem como saber que são ícones distintos.

**Causa raiz em uma frase:** a variante do ícone não faz parte da sua identidade estruturada, então o pipeline não consegue distinguir dois ícones diferentes que compartilham o mesmo nome.

## 6. Restrições que guiaram a decisão

- Nenhum asset é removido da CDN. A correção precisava ser por republicação, não por exclusão.
- Nome publicado é contrato. Renomear a variante já consumida não era opção.

## 7. Correção aplicada

- Republicação da variante preenchida com o nome correto
- Ajuste do nome da variante não preenchida
- Teste unitário que falha o build quando dois ícones compartilham o mesmo nome

## 8. Prevenção

- **Ação:** teste unitário de unicidade de nome no pipeline de ícones
- **Tipo:** Automatizada
- **Dono:** [nome]
- **Prazo:** —
- **Status:** Concluída

Proposta complementar, para validação do time:

- **Ação:** separar `name` e `variant` como campos distintos no metadata do ícone, tornando a colisão impossível por construção em vez de detectável por teste
- **Tipo:** Automatizada (estrutural)
- **Dono:** [nome]
- **Prazo:** [DD/MM/YYYY]
- **Status:** Pendente

## 9. Aprendizado

- Publicação por substituição é perigosa quando o nome é a única chave. Todo ativo publicado deveria falhar ao colidir, nunca sobrescrever em silêncio.
- Convenção dentro do nome não é estrutura. Enquanto a variante for sufixo de string, o pipeline continua cego para ela.
- O teste resolveu o sintoma rápido e valeu a pena, mas a correção definitiva é de modelagem, não de validação.
